﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class p_Manage_Cutters_CuttersInfoDetail : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!Page.IsPostBack)
        {
            string electricTestRecordID;
            int row_index = BaseInfo_DetailsView.Rows.Count;
            System.Diagnostics.Debug.WriteLine(row_index);
            electricTestRecordID = BaseInfo_DetailsView.Rows[row_index-1].Cells[1].Text;

            HttpCookie cookie = new HttpCookie("ElectricTestRecordID");
            cookie.Value = electricTestRecordID;
            Request.Cookies.Add(cookie);
        }
    }
}