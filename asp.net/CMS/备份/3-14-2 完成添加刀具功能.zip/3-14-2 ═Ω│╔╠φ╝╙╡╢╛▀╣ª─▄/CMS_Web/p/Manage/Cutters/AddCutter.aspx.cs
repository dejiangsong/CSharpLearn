﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class p_Manage_Cutters_AddCutter : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            ListItem li = new ListItem();
            li.Value = Profile.UserName;
            li.Text = li.Text;
            UsersGroup_Group_ListBox.Items.Add(li);
        }
    }

    protected void OK_Button_Click(object sender, EventArgs e)
    {
        #region 控件数据获取

        #region Cutters表的数据
        Guid ID = Guid.NewGuid();
        string number = number_TextBox.Text;
        int CutterClass = Int32.Parse(CutterClass_DropDownList.SelectedValue);
        int CutterDetailClass = 0;
        int CutterMaterial = Int32.Parse(Material_DropDownList.SelectedValue);

        if (number == "")
        {
            number = getNumber();
        }
        if (CutterDetailClass_DropDownList.SelectedValue == "")
        {
            try
            {
                //强行插入 ID=0
                using (CMSDB_Entities CMS_EF = new CMSDB_Entities())
                {
                    CutterDetailClass cdc = new CutterDetailClass();
                    cdc.ID = 0;
                    cdc.Name = "";

                    CMS_EF.CutterDetailClass.Add(cdc);
                    CMS_EF.SaveChanges();
                }
            }
            catch (System.Data.Entity.Infrastructure.DbUpdateException ex)
            {
                System.Diagnostics.Debug.WriteLine("i not deal:" + ex.ToString());
            }

            CutterDetailClass = 0;
        }
        else
        {
            CutterDetailClass = Int32.Parse(CutterDetailClass_DropDownList.SelectedValue);
        }
        #endregion

        #region CutterDetail表的数据
        #region CutterDetail - 3DImages
        string filePath_3D = "";

        if (Cutter3DImages_FileUpload.HasFile)
        {
            string virtualFolder = "~/Images/Datas/Cutters/3DImages/";
            string physicalFolder = Server.MapPath(virtualFolder);
            string fileName = Guid.NewGuid().ToString();
            string extension = System.IO.Path.GetExtension(Cutter3DImages_FileUpload.FileName);

            Cutter3DImages_FileUpload.SaveAs(System.IO.Path.Combine(physicalFolder, fileName + extension));       //文件储存
            filePath_3D = virtualFolder + fileName + extension;
        }

        string imageName = "";
        if (Cutter3DImagesName_TextBox.Text != "")
        {
            imageName = Cutter3DImagesName_TextBox.Text;
        }
        else
        {
            imageName = CutterClass_DropDownList.SelectedItem.Text + getIntID();
        }
        #endregion

        #region CutterDetail - Images
        string filePath_image = "";

        if (Image_Fileupload.HasFile)
        {
            string virtualFolder = "~/Images/Datas/Cutters/ActualImages/";
            string physicalFolder = Server.MapPath(virtualFolder);
            string fileName = Guid.NewGuid().ToString();
            string extension = System.IO.Path.GetExtension(Image_Fileupload.FileName);

            Image_Fileupload.SaveAs(System.IO.Path.Combine(physicalFolder, fileName + extension));       //文件储存
            filePath_image = virtualFolder + fileName + extension;
        }

        #endregion

        #region CutterNotes
        string note = "";
        note = Note_TextBox.Text;
        #endregion
        #endregion
        #endregion

        
        #region 插入数据
        try
        {
            using (CMSDB_Entities CMS_EF = new CMSDB_Entities())
            {
                #region 插入Cutters
                Cutters c = new Cutters();
                c.ID = ID;
                c.number = number;
                c.ClassID = CutterClass;
                c.DetailClassID = CutterDetailClass;
                c.MaterialID = CutterMaterial;

                CMS_EF.Cutters.Add(c);
                #endregion

                #region 插入CutterDetail
                #region 基本数据
                CuttersDetail cd = new CuttersDetail();
                cd.ID = c.ID;
                cd.CreateDate = System.DateTime.Now;
                cd.LastUseDate = cd.CreateDate;
                cd.IsWorking = false;
                #endregion

                #region 详细数据
                #region 详细数据 - Cutter3DImageID
                if (!Cutter3DImages_FileUpload.HasFile)
                {
                    cd.Cutter3DImageID = Int32.Parse(Cutter3DImages_DropDownList.SelectedValue);
                }
                else
                    cd.Cutter3DImageID = getIntID();
                #endregion

                #region 详细数据 - UsersGroupID
                List<string> ug_list = new List<string>();
                List<string> u_list = new List<string>();

                foreach (ListItem li in UsersGroup_Group_ListBox.Items)
                {
                    if (li.Value != "")
                        ug_list.Add(li.Value);
                }
                foreach (string s in ug_list)
                {
                    if (Membership.FindUsersByName(s).Count > 0)
                        u_list.Add(s);
                }

                cd.UsersGroupID = getIntID();
                #endregion

                #region 详细数据 - CutterImageID
                cd.ImageID = getIntID();
                #endregion

                #region 详细数据 - CutterNotes
                cd.NoteID = getIntID();
                #endregion
                #endregion

                CMS_EF.CuttersDetail.Add(cd);
                #endregion

                #region 其它表
                #region 其它表 - Cutter3DImages
                if (Cutter3DImages_FileUpload.HasFile)
                {
                    Cutter3DImages c3di = new Cutter3DImages();
                    c3di.ID = (int)cd.Cutter3DImageID;
                    c3di.ClassID = c.ClassID;
                    c3di.UserName = Profile.UserName == null ? "" : Profile.UserName;
                    c3di.Name = imageName;
                    c3di.ImagePath = filePath_3D;

                    CMS_EF.Cutter3DImages.Add(c3di);
                }
                #endregion

                #region 其它表 - CutterUsersGroup
                foreach (string s in u_list)
                {
                    CutterUsersGroup cug = new CutterUsersGroup();
                    cug.GroupID = (int)cd.UsersGroupID;

                    cug.ID = getIntID();
                    cug.UserName = s;

                    CMS_EF.CutterUsersGroup.Add(cug);
                    CMS_EF.SaveChanges();
                }
                #endregion

                #region 其它表 - CutterImages
                CutterImages ci = new CutterImages();
                ci.ID = getIntID();
                ci.ImageID = cd.ImageID;
                ci.DateTime = System.DateTime.Now;
                ci.ImagePath = filePath_image;

                CMS_EF.CutterImages.Add(ci);
                #endregion

                #region 其它表 - CutterNotes
                CutterNotes cn = new CutterNotes();
                cn.ID = getIntID();
                cn.NoteID = cd.NoteID;
                cn.Note = note;

                CMS_EF.CutterNotes.Add(cn);
                #endregion
                #endregion

                CMS_EF.SaveChanges();
            }
        }
        catch
        { }
        #endregion
    }



    #region 详细类扩展
    //TODO 不能自动刷新控件中的数据
    protected void CutterDetailClassEx_Button_Click(object sender, EventArgs e)
    {
        CutterDetailClassEx_Panel.Visible = !CutterDetailClassEx_Panel.Visible;
    }

    //TODO 可以插入相同的内容
    protected void AddNewDetailClass_Button_Click(object sender, EventArgs e)
    {
        try
        {
            using (CMSDB_Entities CMS_EF = new CMSDB_Entities())
            {
                CutterDetailClass cdc = new CutterDetailClass();
                cdc.ID = getIntID();
                cdc.Name = CutterDetailClass_TextBox.Text;
                cdc.ClassID = Int32.Parse(CutterClass_DropDownList.SelectedValue);
                cdc.UserName = Profile.UserName;

                CMS_EF.CutterDetailClass.Add(cdc);
                CMS_EF.SaveChanges();
            }
        }
        catch { }
    }

    protected void ChangeDetailClass_Button_Click(object sender, EventArgs e)
    {
        int cdcv = Int32.Parse(CutterDetailClass_DropDownList.SelectedValue);

        try
        {
            using (CMSDB_Entities CMS_EF = new CMSDB_Entities())
            {
                var cdc = CMS_EF.CutterDetailClass.Single(c => c.ID == cdcv);
                cdc.Name = ChangeDetailClass_TextBox.Text;

                CMS_EF.SaveChanges();
            }
        }
        catch { }
    }

    protected void DeleteDetailClass_Button_Click(object sender, EventArgs e)
    {
        int cdcv = Int32.Parse(CutterDetailClass_DropDownList.SelectedValue);

        try
        {
            using (CMSDB_Entities CMS_EF = new CMSDB_Entities())
            {
                var cdc = CMS_EF.CutterDetailClass.Single(c => c.ID == cdcv);

                CMS_EF.CutterDetailClass.Remove(cdc);
                CMS_EF.SaveChanges();
            }
        }
        catch { }
    }

    #endregion

    #region 方法
    /// <summary>
    /// 设置一个由
    ///     字母+日期时间+字母+随机数
    /// 组成的字符串
    /// </summary>
    /// <调用者>
    /// Cutter-number
    /// </调用者>>
    /// <returns></returns>
    private string getNumber()
    {
        string header = "dft";
        string currentDateTime = "";
        int rand = 0;
        string number = "";

        currentDateTime = System.DateTime.Now.ToString();

        //正则
        currentDateTime = Regex.Replace(currentDateTime, "[/| |:]", "");
        currentDateTime = currentDateTime.Remove(0, 2);
        currentDateTime = currentDateTime.Substring(0, currentDateTime.Length - 2);   //秒

        number = header + currentDateTime;

        #region //查询数据库排除重复项
        //查询数据库排除重复项
        //int no = 0;

        //using (CMSDB_Entities CMS_EF = new CMSDB_Entities())
        //{
        //    try
        //    {
        //        var query = (from n in CMS_EF.Cutters
        //                     join c in CMS_EF.CuttersDetail on n.ID equals c.ID
        //                     where n.number.Contains(number)
        //                     orderby c.CreateDate descending
        //                     select n.number).Single();

        //        Regex rg = new Regex("(?<=(k))[\\s\\S]*");
        //        no = Int32.Parse(rg.Match(query).Value);

        //        no++;
        //    }
        //    catch
        //    {

        //    }
        //}
        #endregion

        var seed = Guid.NewGuid().GetHashCode();
        Random r = new Random(seed);
        rand = r.Next(0, 1000);

        number += "k" + rand;

        return number;
    }

    /// <summary>
    /// 设置一个由
    ///     日期时间+随机数
    /// 组成的字符串
    /// </summary>
    /// <调用者>
    /// Cutter3DImages-ID、Name
    /// UserGroup-ID、GroupID
    /// CutterImages-ID、ImageID
    /// CutterNote-ID、NoteID
    /// </调用者>>
    /// <returns></returns>
    private int getIntID()
    {
        string currentDateTime = "";
        int rand = 0;
        string number = "";

        currentDateTime = System.DateTime.Now.ToString();

        //正则
        currentDateTime = Regex.Replace(currentDateTime, "[/]", "");
        currentDateTime = currentDateTime.Remove(0, 2);
        currentDateTime = currentDateTime.Substring(0, currentDateTime.IndexOf(" "));

        number = currentDateTime;

        var seed = Guid.NewGuid().GetHashCode();
        Random r = new Random(seed);
        rand = r.Next(0, 1000);

        number += rand;

        return Int32.Parse(number);
    }

    /// <summary>
    /// 得到一个cookie中myUsersGroupCookie的值
    /// </summary>
    /// <param name="op">
    ///     true:添加
    ///     false:移除
    /// </param>
    /// <returns>返回一个List<string>的用户组列表</returns>
    private List<string> getUgg_list(bool op)
    {
        List<string> ugg_list = new List<string>();

        if (op)
        {
            string ug_result = UsersGroup_Result_ListBox.SelectedValue;

            if (Request.Cookies["myUsersGroupCookie"] == null)
            {
                HttpCookie cookie_new = new HttpCookie("myUsersGroupCookie");
                DateTime dt = DateTime.Now;
                TimeSpan ts = new TimeSpan(0, 0, 1, 0, 0);
                cookie_new.Expires = dt.Add(ts);
                if (Profile.UserName != null)
                    cookie_new.Values.Set(Profile.UserName, Profile.UserName);
                Response.AppendCookie(cookie_new);
            }

            var cookie = Request.Cookies["myUsersGroupCookie"];

            if (ug_result != "" && ug_result != null)
                cookie.Values[ug_result] = ug_result;
            Response.AppendCookie(cookie);

            foreach (string s in cookie.Values.AllKeys)
            {
                if (cookie.Values[s] != "")
                    ugg_list.Add(cookie.Values[s]);
            }
        }
        else
        {
            string ug_g = UsersGroup_Group_ListBox.SelectedValue;

            if (Request.Cookies["myUsersGroupCookie"] != null)
            {
                var cookie = Request.Cookies["myUsersGroupCookie"];

                if (ug_g != "" && ug_g != null)
                    cookie.Values.Remove(ug_g);
                Response.AppendCookie(cookie);

                foreach (string s in cookie.Values.AllKeys)
                {
                    if (cookie.Values[s] != "")
                        ugg_list.Add(cookie.Values[s]);
                }
            }
        }

        return ugg_list;
    }
    #endregion

    #region 事件

    #region 预览模型图
    protected void Preview3DImage_Button_Click(object sender, EventArgs e)
    {
        if (Cutter3DImages_FileUpload.HasFile)
        {
            string virtualFolder = "~/Images/Datas/temp/";
            string physicalFolder = Server.MapPath(virtualFolder);
            string fileName = Guid.NewGuid().ToString();
            string extension = System.IO.Path.GetExtension(Cutter3DImages_FileUpload.FileName);

            Cutter3DImages_FileUpload.SaveAs(System.IO.Path.Combine(physicalFolder, fileName + extension));       //文件储存
            Cutter3DImages_Image.ImageUrl = virtualFolder + fileName + extension;
        }
    }
    #endregion

    #region 查找用户
    //TODO 只能完全匹配后才能查询到
    protected void UsersGroup_Search_Button_Click(object sender, EventArgs e)
    {
        if (UsersGroup_Input_TextBox.Text != "")
        {
            var users = Membership.FindUsersByName(UsersGroup_Input_TextBox.Text);

            UsersGroup_Result_ListBox.DataSource = users;
            UsersGroup_Result_ListBox.DataBind();
        }
    }
    #endregion

    #region 添加用户到组
    protected void UsersGroup_Add_Button_Click(object sender, EventArgs e)
    {
        List<string> ugg_list = getUgg_list(true);

        UsersGroup_Group_ListBox.DataSource = ugg_list;
        UsersGroup_Group_ListBox.DataBind();
    }
    #endregion

    #region 将用户从组移除
    protected void UsersGroup_Delete_Button_Click(object sender, EventArgs e)
    {
        List<string> ugg_list = getUgg_list(false);

        UsersGroup_Group_ListBox.DataSource = ugg_list;
        UsersGroup_Group_ListBox.DataBind();
    }
    #endregion

    #region 预览实图
    protected void PreviewImage_Button_Click(object sender, EventArgs e)
    {
        if (Image_Fileupload.HasFile)
        {
            string virtualFolder = "~/Images/Datas/temp/";
            string physicalFolder = Server.MapPath(virtualFolder);
            string fileName = Guid.NewGuid().ToString();
            string extension = System.IO.Path.GetExtension(Image_Fileupload.FileName);

            Image_Fileupload.SaveAs(System.IO.Path.Combine(physicalFolder, fileName + extension));       //文件储存
            Image_Image.ImageUrl = virtualFolder + fileName + extension;
        }
    }
    #endregion
    #endregion
}