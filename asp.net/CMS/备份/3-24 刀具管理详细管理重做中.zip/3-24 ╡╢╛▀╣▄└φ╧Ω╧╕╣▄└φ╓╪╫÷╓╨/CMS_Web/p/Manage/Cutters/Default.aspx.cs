﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class p_Manage_Cutters_Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            try
            {
                string qs = Request.QueryString.Get("number");
                using (CMSDB_Entities CMS_EF = new CMSDB_Entities())
                {
                    var query = (from c in CMS_EF.Cutters
                                 where c.number == qs
                                 select c.CuttersDetail.ImageID).Single();

                    EntityDataSource1.Where = "it.imageID == " + query;

                }
            }
            catch { }
        }
    }

    protected void ListView1_ItemUpdating(object sender, ListViewUpdateEventArgs e)
    {
        ListViewItem lvi = ListView1.Items[this.ListView1.EditIndex];
        DropDownList ddl = (DropDownList)lvi.FindControl("ImagePathDropDownList");
        e.NewValues["ImagePath"] = ddl.SelectedValue;
    }
}