﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class p_Manage_Cutters_AddCutter : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void OK_Button_Click(object sender, EventArgs e)
    {
        Guid ID = Guid.NewGuid();
        string number = number_TextBox.Text;
        int CutterClass = Int32.Parse(CutterClass_DropDownList.SelectedValue);
        int CutterDetailClass = 0;
        int CutterMaterial = Int32.Parse(Material_DropDownList.SelectedValue);


        #region 控件数据获取
        if (number == "")
        {
            number = getNumber();
        }
        if (CutterDetailClass_DropDownList.SelectedValue == "")
        {
            try
            {
                //强行插入 ID=0
                using (CMSDB_Entities CMS_EF = new CMSDB_Entities())
                {
                    CutterDetailClass cdc = new CutterDetailClass();
                    cdc.ID = 0;
                    cdc.Name = "";

                    CMS_EF.CutterDetailClass.Add(cdc);
                    CMS_EF.SaveChanges();
                }
            }
            catch (System.Data.Entity.Infrastructure.DbUpdateException ex)
            {
                System.Diagnostics.Debug.WriteLine("i not deal:" + ex.ToString());
            }

            CutterDetailClass = 0;
        }
        else
        {
            CutterDetailClass = Int32.Parse(CutterDetailClass_DropDownList.SelectedValue);
        }
        #endregion


        #region 控件数据获取
        if (number == "")
        {
            number = getNumber();
        }
        if (CutterDetailClass_DropDownList.SelectedValue == "")
        {
            try
            {
                //强行插入 ID=0
                using (CMSDB_Entities CMS_EF = new CMSDB_Entities())
                {
                    CutterDetailClass cdc = new CutterDetailClass();
                    cdc.ID = 0;
                    cdc.Name = "";

                    CMS_EF.CutterDetailClass.Add(cdc);
                    CMS_EF.SaveChanges();
                }
            }
            catch (System.Data.Entity.Infrastructure.DbUpdateException ex)
            {
                System.Diagnostics.Debug.WriteLine("i not deal:" + ex.ToString());
            }

            CutterDetailClass = 0;
        }
        else
        {
            CutterDetailClass = Int32.Parse(CutterDetailClass_DropDownList.SelectedValue);
        }
        #endregion


        #region 插入数据
        try
        {
            using (CMSDB_Entities CMS_EF = new CMSDB_Entities())
            {
                #region 插入Cutters
                Cutters c = new Cutters();
                c.ID = ID;
                c.number = number;
                c.ClassID = CutterClass;
                c.DetailClassID = CutterDetailClass;
                c.MaterialID = CutterMaterial;

                CMS_EF.Cutters.Add(c);
                #endregion

                #region 插入CutterDetail
                CuttersDetail cd = new CuttersDetail();
                cd.ID = c.ID;

                CMS_EF.CuttersDetail.Add(cd);
                #endregion

                CMS_EF.SaveChanges();
            }
        }
        catch
        { }
        #endregion
    }

    #region 方法
    /// <summary>
    /// 设置一个由
    ///     字母+日期时间+字母+随机数
    /// 组成的字符串
    /// </summary>
    /// <returns></returns>
    private string getNumber()
    {
        string header = "dft";
        string currentDateTime = null;
        int rand = 0;
        string number = null;

        currentDateTime = System.DateTime.Now.ToString();

        //正则
        currentDateTime = Regex.Replace(currentDateTime, "[/| |:]", "");
        currentDateTime = currentDateTime.Remove(0, 2);
        currentDateTime = currentDateTime.Substring(0, currentDateTime.Length - 2);   //秒

        number = header + currentDateTime;

        #region //查询数据库排除重复项
        //查询数据库排除重复项
        //int no = 0;

        //using (CMSDB_Entities CMS_EF = new CMSDB_Entities())
        //{
        //    try
        //    {
        //        var query = (from n in CMS_EF.Cutters
        //                     join c in CMS_EF.CuttersDetail on n.ID equals c.ID
        //                     where n.number.Contains(number)
        //                     orderby c.CreateDate descending
        //                     select n.number).Single();

        //        Regex rg = new Regex("(?<=(k))[\\s\\S]*");
        //        no = Int32.Parse(rg.Match(query).Value);

        //        no++;
        //    }
        //    catch
        //    {

        //    }
        //}
        #endregion

        Random r = new Random();
        rand = r.Next(0, 1000);

        number += "k" + rand;

        return number;
    }

    /// <summary>
    /// 设置一个由
    ///     日期时间+随机数
    /// 组成的字符串
    /// </summary>
    /// <returns></returns>
    private int getIntID()
    {
        string currentDateTime = null;
        int rand = 0;
        string number = null;

        currentDateTime = System.DateTime.Now.ToString();

        //正则
        currentDateTime = Regex.Replace(currentDateTime, "[/]", "");
        currentDateTime = currentDateTime.Remove(0, 2);
        currentDateTime = currentDateTime.Substring(0, currentDateTime.IndexOf(" "));

        number = currentDateTime;

        Random r = new Random();
        rand = r.Next(0, 1000);

        number += rand;

        return Int32.Parse(number);
    }
    #endregion

    #region 详细类扩展
    protected void CutterDetailClassEx_Button_Click(object sender, EventArgs e)
    {
        CutterDetailClassEx_Panel.Visible = !CutterDetailClassEx_Panel.Visible;
    }

    protected void AddNewDetailClass_Button_Click(object sender, EventArgs e)
    {
        try
        {
            using (CMSDB_Entities CMS_EF = new CMSDB_Entities())
            {
                CutterDetailClass cdc = new CutterDetailClass();
                cdc.ID = getIntID();
                cdc.Name = CutterDetailClass_TextBox.Text;
                cdc.ClassID = Int32.Parse(CutterClass_DropDownList.SelectedValue);
                cdc.UserName = Profile.UserName;

                CMS_EF.CutterDetailClass.Add(cdc);
                CMS_EF.SaveChanges();
            }
        }
        catch { }
    }
    #endregion
}