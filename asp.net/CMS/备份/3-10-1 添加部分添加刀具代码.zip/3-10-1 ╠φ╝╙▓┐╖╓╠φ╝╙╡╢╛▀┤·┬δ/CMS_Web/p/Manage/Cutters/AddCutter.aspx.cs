﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


public partial class p_Manage_Cutters_AddCutter : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void OK_Button_Click(object sender, EventArgs e)
    {
        string ID = Guid.NewGuid().ToString();
        string number = getNumber();
        int CutterClass = Int32.Parse(CutterClass_DropDownList.SelectedValue);


    }


    /// <summary>
    /// 设置一个由
    ///     字母+日期时间+字母+随机数
    /// 组成的字符串
    /// </summary>
    /// <returns></returns>
    private string getNumber()
    {
        string header = "dft";
        string currentDateTime = null;
        int rand = 0;
        string number = null;

        currentDateTime = System.DateTime.Now.ToString();

        //正则
        currentDateTime = Regex.Replace(currentDateTime, "[/| |:]", "");
        currentDateTime = currentDateTime.Remove(0, 2);
        currentDateTime = currentDateTime.Substring(0, currentDateTime.Length - 2);   //秒

        number = header + currentDateTime;

        //查询数据库排除重复项
        //int no = 0;

        //using (CMSDB_Entities CMS_EF = new CMSDB_Entities())
        //{
        //    try
        //    {
        //        var query = (from n in CMS_EF.Cutters
        //                     join c in CMS_EF.CuttersDetail on n.ID equals c.ID
        //                     where n.number.Contains(number)
        //                     orderby c.CreateDate descending
        //                     select n.number).Single();

        //        Regex rg = new Regex("(?<=(k))[\\s\\S]*");
        //        no = Int32.Parse(rg.Match(query).Value);

        //        no++;
        //    }
        //    catch
        //    {

        //    }
        //}

        Random r = new Random();
        rand = r.Next(0, 1000);

        number += "k" + rand;

        //输出
        System.Diagnostics.Debug.WriteLine(rand);
        System.Diagnostics.Debug.WriteLine(number);

        return number;
    }
}